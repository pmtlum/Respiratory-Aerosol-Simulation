function k = kair( T ) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Yang Wang, Guang Xu, and Yue-Wern Huang
% 25 July 2020
%
% This function defines the thermal conductivity of bulk air. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


k = 0.026*((T/300)^(1/2));               % [W/(m*K)] or [J/(kg*K)] 

end 
