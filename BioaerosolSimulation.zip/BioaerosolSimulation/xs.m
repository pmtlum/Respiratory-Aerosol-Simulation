function result = xs( Ts, totalP, Da ,Da0) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Bennett Naden and Jake Leonardis 
% 25 April 2013 
% Aerosol Dynamics Clinic 2013 
% Combining COMSOL and Matlab to simulate droplet growth 
% 
% Function defining the saturated mole fraction of water 

% Steven Spielman 2013-05-28
% (Function applies to surface of a droplet of diameter Da)
% Added solute-like term to handle Da->0 problem
% The solute acts like a soluble particle of diameter Da0 with the 
% density and molar mass of water.  For now the diameter of this
% ficticious particle is hard-coded, but it should maybe be set to 
% track the Da0 initial particle size in the main program.

% Da0 = 10e-9;             % Diameter of non-evaporating, soluble core [ m ]
R = 8.3144621;           % Ideal gas constant [J/(mol*K)] 
Mw = .0180153;           % Molar mass of water [kg/mol] 
rhoW = 1000;             % Density of liquid water [kg/m^3] 

KelvinTerm = exp( (4*surf_tens(Ts)*Mw)/(rhoW*R*Ts*Da) ...     % Kelvin term 
    - (Da0/Da)^3 ) ;         % vapor reduction due to solute

% KelvinTerm = exp( (4*surf_tens(Ts)*Mw)/(rhoW*R*Ts*Da)) ;         % vapor reduction due to solute

result = (p_sat(Ts)/totalP)*KelvinTerm;            % Unitless 

end 
