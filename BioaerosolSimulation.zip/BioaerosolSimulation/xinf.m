function result = xinf( T, c, totalP ) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Bennett Naden and Jake Leonardis 
% 25 April 2013 
% Aerosol Dynamics Clinic 2013 
% Combining COMSOL and Matlab to simulate droplet growth 
% 
% Function defining the mole fraction at infinity 

R = 8.3144621;                          % Ideal gas constant [J/(mol*K)] 
result = R*c*T/totalP;                  % Unitless 

end 
