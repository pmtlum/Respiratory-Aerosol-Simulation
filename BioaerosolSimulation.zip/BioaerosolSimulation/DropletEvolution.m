function [Dp_ini,Dp_final,n_virus,Dp_v_ini,Dp_v_final,z_final,Dp_v_set]=DropletEvolution(t)
% Dp_ini: Initial droplet size
% Dp_final: Final droplet size
% n_virus: Number of virus copies in the droplet
% Dp_v_ini: Initial size of droplet that contains virus
% Dp_v_final: Final size of droplet that contains virus
% z_final: Final vertical distance
% Dp_v_set: Final size of settled droplet that contains virus

T=293.15;
RH=0.5;
mu=16e-6; 
% Coughing: 13.5 um from Chao et al 2009; 12.3 um, Duguid, 1946;  
% 3000 particles, 50 mph
% Speaking: 16.0 um from Chao et al 2009; 13.4 um, Duguid, 1946; 100 um, Loudon $ Roberts, 1967;
% 40000 particles, 200 mph https://www.sott.net/article/277306-Germs-from-coughs-and-sneezes-travel-further-than-previously-thought

sigma=0.55; % This value should be ln(sigma), not sigma
rou_sol=1000;% density of solution initially, 1000 kg/m3
rou_salt=2160; % density of NaCl
c_sol=0.009; % 0.9%
Dp_virus=100e-9;
v_virus=pi/6*Dp_virus^3;
c=7e6*1e6; % copies of viral load per m3; 2.35e9 to 7e6/ml for SARS-COV-2 ref: https://www.thelancet.com/action/showPdf?pii=S1473-3099%2820%2930196-1

% Dp=normrnd(log10(mu),sigma,[1,100]);
Dp0=10^(normrnd(log10(mu),sigma)); % randomly generated droplet size - initial size
% Dp0=500e-6;

% If need to consider mask filtration, below is the size dependent
% filtraiton efficiency

% FE_grp=[3.79627E-08	0.93888547
% 4.93911E-08	0.872533628
% 5.91349E-08	0.826917522
% 7.27858E-08	0.773012145
% 8.83119E-08	0.710855176
% 1.08698E-07	0.6569498
% 1.33767E-07	0.598912347
% 1.62357E-07	0.54501953
% 2.08696E-07	0.52413308
% 2.6421E-07	0.47433466
% 3.12478E-07	0.470051871
% 3.74708E-07	0.461624446
% 5.10008E-07	0.469612288
% 6.5648E-07	0.481782444
% 7.7803E-07	0.527084563
% 8.96318E-07	0.564147649
% 1.03313E-06	0.613606963
% 1.14166E-06	0.658971879
% 1.28003E-06	0.716720463
% 1.39507E-06	0.766230015
% 1.58566E-06	0.815701888
% 1.77693E-06	0.861054244
% 2.01828E-06	0.893997815
% 2.32554E-06	0.935192977
% 2.91382E-06	0.972180706
% 3.64838E-06	0.992640133
% 4.8295E-06	1
% 6.38967E-06	1
% 1       1
% ];
% FE=interp1(log(FE_grp(:,1)),FE_grp(:,2),log(Dp0))*0.95;
% FE=0;


V0=Dp0^3*pi/6; % initial droplet volume
lambda=V0*c; % initial number of viruses in the droplet (ideally)
n_virus=poissrnd(lambda);% actual number of viruses following Poission Distribution
V_virus=n_virus*v_virus;% Total virus volume in this particle
Dp_agg_virus=(V_virus/pi*6)^(1/3);% Volume of aggregated viruses
V_sol_0=V0-V_virus;% Volume of solution at initial time;
M_salt=V0*rou_sol*c_sol; % mass of salt (assuming NaCl)
V_salt=M_salt/rou_salt;
V_solid=V_salt+V_virus;
Dp_solid=(V_solid*6/pi)^(1/3);

% n2=M_salt/36.5e-3; % moles of NaCl
% v1_bar=18e-6; % molar volume of water

options = odeset('RelTol',1e-7,'AbsTol',[1e-9,1e-2,1e-3,1e-4]);  % These tolerances improve 
[t,y]=ode15s(@(t,y) EvapEquations(t,y,Dp_solid,T,RH),[0 t],[Dp0,273.15+37,0,0],options);
% Note: [Dp0, T, 0, 0] are initial conditions of droplet size, droplet surface temperature, ...
% ... vertical distance travelled, and vertical velocity. To change
% surface temperature to 37 Celsius, this temperature can be changed. 
Dp_final=y(end,1);
Dp_ini=Dp0;
z_final=y(end,3);
vz_final=y(end,4);

% x_final=y(end,5);
% vx_final=y(end,6);

% if z_final>1.7
%     z_final=1.7;
% end
% random_n=rand();
% if random_n<FE
%     penetration=0;
% else
%     penetration=1;
% end

if n_virus==0
    Dp_v_final=nan;
    Dp_v_ini=nan;
else
    Dp_v_final=Dp_final;
    Dp_v_ini=Dp_ini;
end

if z_final>1.7
    Dp_v_set=Dp_final;
else
    Dp_v_set=nan;
end

% if ~penetration 
%    Dp_ini=nan;
%    Dp_final=nan;
%    n_virus=nan;
%    Dp_v_ini=nan;
%    Dp_v_final=nan;
%    z_final=nan;
%    Dp_v_set=nan;
% end