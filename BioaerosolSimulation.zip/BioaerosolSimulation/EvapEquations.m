function dydz = EvapEquations(t,y,Da0,T,RH)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Yang Wang, Guang Xu, and Yue-Wern Huang
% 25 July 2020
%
% adapted from
% Bennett Naden and Jake Leonardis 
% 25 April 2013 

% This function defines the droplet evaporation differential equations that
% will be solved using ode15s.
%
% Inputs: Independent variable t
%           Dependent variable y = [Da Ts z vz]
%           Da: droplet diameter
%           Ts: droplet surface temperature
%           z: droplet vertical distance travelled
%           vz: droplet vertical velocity
%           T: Background temperature
%           c: Background concentration
%           Da0: Initial particle diameter 
%
% Output: dydz is the function handle used in the growth script.
% y in this case is a vector of the dependent variables (Da,Ts,z,vz)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First, define physical constants

R = 8.3144621;               % Ideal gas constant [J/(mol*K)]
Mw = .0180153;               % Molar mass of water [kg/mol]
rhoW = 1000;                 % Density of liquid water [kg/m^3]
totalP = 101325;             % Total tube pressure, ~atmospheric pressure [Pa]
Hvap = 2.257e6;              % Heat of vaporization of liquid water [J/kg]
cp = 4181.3;                 % Heat capacity of air at constant pressure, with
% respect to mass [J/(kg*K)]
% Constants defined

% Next, set up the dependent variables Da and Ts

dydz = zeros(4,1);                    % create the output vector
Da = y(1);                            % droplet diameter
Ts = y(2);                            % drplet surface temperature
z = y(3);                             % vertical distance
vz = y(4);                            % vertical velocity
% x = y(5);                       % horizontal distance - not being used
% vx = y(6);                      % horizontal velocity - not being used

c = RH*p_sat(T)/R/T;                % water vapor molar concentration at inf

if Da<Da0 % If the droplet size is below the dry size, then no need to integrate any more
    dydz(1)=0;
    dydz(2)=0;
else    
    % According to ﻿Journal of Aerosol Science 108 (2017) 44–55
    % dDa / dt=4 * Dw * Mw / rhoW * (Cinf - Cs) / Da * phi
    % phi considers the non-continuum effect of the condensation growth
    % C = p / RT
    % x is mole fraction of water in air: x = p / totalP
    % dDa / dt=4 * Dw * Mw / rhoW * totalP / R / T * (xinf - xs) / Da
    % dDa / dt = 4 * Dw * Mw * totalP / (rhoW * R * T * Da) * (xinf - xs)
    dydz(1) = ...
        (4*Dw(T)*Mw*totalP/(rhoW*R*T*Da) )*(xinf(T,c,totalP) - xs(Ts,totalP,Da,Da0))*...
        phi(Da,T);
    % md * cp * dTs/dt = Ad * h * (T - Ts) + Hvap * dmd / dt
    % h = 2 / Dp * kair;  
    % dTs/dt = 3 / (rhoW * Da * cp) * (Hvap * rhoW * dDa / dt - 4 * kair * (Ts - T) / Da)
    dydz(2) = (3/(rhoW*Da*cp)*(Hvap*rhoW*dydz(1) - 4*kair(Ts)*(Ts-T)/Da));
end

Rep = 1.27*Da*vz/1.98e-5;

% consider particle movement: dz / dt = vz;
dydz(3) = vz;

if Rep<=1&&Rep>0
    CD=24./Rep;
elseif Rep>500||Rep<=0
    CD=0.44;
else
    CD=24./Rep.*(1+0.15*Rep.^0.687);
end

% consider particle movement: dvz / dt = 9.8 - 1 / (rhoW * Da^3 * pi / 6)..
% ... * 1/2 * rhoAir * vz^2 * Acros * CD
rhoAir = 1.27; % 

dydz(4) = 9.8 - 1/(rhoW*Da.^3*pi/6)*1/2*rhoAir*vz^2*1/4*pi*Da.^2*CD;

end