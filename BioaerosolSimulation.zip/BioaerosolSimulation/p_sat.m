function P = p_sat( T ) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Bennett Naden and Jake Leonardis 
% 25 April 2013 
% Aerosol Dynamics Clinic 2013 
% Combining COMSOL and Matlab to simulate droplet growth 
% 
% This function defines the saturated vapor pressure of water, analytic 

C0 = 37;            % Constant [K] 
B0 = 4060;          % Constant [K] 
P0 = 17.93e9;       % Constant [Pa] 

P = P0*exp(-B0/(T-C0)); % [Pa] 

end 

