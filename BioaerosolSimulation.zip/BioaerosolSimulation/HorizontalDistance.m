function [tc,xc]=HorizontalDistance(Dp0,hc)
% hc: height of emission
% xc: hotizontal distance (m)
% tc: settlign time

% if nargin<2
%     Dp0=100e-6;
%     hc=1.5;
% end

T=293.15;
RH=0.5;
mu=16e-6; 
% Coughing: 13.5 um from Chao et al 2009; 12.3 um, Duguid, 1946;  
% 3000 particles, 50 mph
% Speaking: 16.0 um from Chao et al 2009; 13.4 um, Duguid, 1946; 100 um, Loudon $ Roberts, 1967;
% 40000 particles, 200 mph https://www.sott.net/article/277306-Germs-from-coughs-and-sneezes-travel-further-than-previously-thought

sigma=0.55;
rou_sol=1000;% density of solution initially, 1000 kg/m3
rou_salt=2160; % density of NaCl
c_sol=0.009; % 0.9%
Dp_virus=100e-9;
v_virus=pi/6*Dp_virus^3;
c=7e6*1e6; % copies of viral load per m3; 2.35e9 to 7e6/ml for SARS-COV-2 ref: https://www.thelancet.com/action/showPdf?pii=S1473-3099%2820%2930196-1

t=200;

V0=Dp0^3*pi/6; % initial droplet volume
lambda=V0*c; % initial number of viruses in the droplet (ideally)
n_virus=poissrnd(lambda);% actual number of viruses following Poission Distribution
V_virus=n_virus*v_virus;% Total virus volume in this particle
Dp_agg_virus=(V_virus/pi*6)^(1/3);% Volume of aggregated viruses
V_sol_0=V0-V_virus;% Volume of solution at initial time;
M_salt=V0*rou_sol*c_sol; % mass of salt (assuming NaCl)
V_salt=M_salt/rou_salt;
V_solid=V_salt+V_virus;
Dp_solid=(V_solid*6/pi)^(1/3);
% Dp_solid=Dp0


% n2=M_salt/36.5e-3; % moles of NaCl
% v1_bar=18e-6; % molar volume of water

options = odeset('RelTol',1e-7,'AbsTol',[1e-9,1e-2,1e-3,1e-4]);  % These tolerances improve 
[t,y]=ode15s(@(t,y) EvapEquations(t,y,Dp_solid,T,RH),[0 t],[Dp0,T,0,0],options);
Dp_final=y(end,1);
Dp_ini=Dp0;
z_final=y(end,3);
vz_final=y(end,4);
y(:,5)=(2.625*t+0.0369).^(1/3)-0.333;
Rep = 1.27*y(:,1).*y(:,4)/1.98e-5;

tc=interp1(y(:,3),t,hc);
xc=interp1(t,y(:,5),tc);
1+1