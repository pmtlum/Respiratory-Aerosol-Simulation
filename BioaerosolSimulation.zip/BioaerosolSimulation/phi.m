function result = phi( Da,T ) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Bennett Naden and Jake Leonardis 
% 25 April 2013 
% Aerosol Dynamics Clinic 2013 
% Combining COMSOL and Matlab to simulate droplet growth 
% 
% This function evaluates phi, the continuum effects term in the droplet 
% growth equations. 

R = 8.3144621;                                   % Ideal gas constant [J/(mol*K)] 
Mw = .0180153;                                   % Molar mass of water [kg/mol] 

meanMolSpeed = sqrt((8*R*T)/(pi*Mw));            % Mean molecular speed [m/s] 
lambda = 3*Dw(T)/meanMolSpeed;                   % Mean free path of water vapor in 
                                                 % air [m] 

Kn = lambda/(Da/2);                              % Knudsen number, dimensionless 

result = (1+Kn)/(1.33*Kn^2+1.71*Kn+1); 
end 
