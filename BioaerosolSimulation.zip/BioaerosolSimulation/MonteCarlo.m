function [Dp_ini,Dp_v_ini,Dp_final,Dp_v_final,Dp_v_set,n_virus,z_final]=MonteCarlo(t,n)
if nargin<2
    t=10;
    n=3000;
end

Dp_ini=nan(1,n);
Dp_final=nan(1,n);
Dp_v_ini=nan(1,n);
Dp_v_final=nan(1,n);
n_virus=nan(1,n);
z_final=nan(1,n);
x_final=nan(1,n);
Dp_v_set=nan(1,n);

option.plot=            1;

for i=1:1:n
%     i
    [Dp_ini(i),Dp_final(i),n_virus(i),Dp_v_ini(i),Dp_v_final(i),z_final(i),Dp_v_set(i)]=DropletEvolution(t);
end

tickspos=[[1:1:9]*10^-8,[1:1:9]*10^-7,[1:1:9]*10^-6,[1:1:9]*10^-5,[1:1:10]*10^-4];
binedges=[-8:0.1:3];

if option.plot
    figure
    subplot(3,1,1)
    histogram(log10(Dp_ini),binedges)
    hold on
    histogram(log10(Dp_v_ini),binedges)
    xlim([-8,-3])
    xlabel('{\itD}_{p,i} ({\mu}m)');
    ylabel('Counts');
%     ylim([0 250]);
%     yticks([0:50:250]);
    xticks(log10(tickspos));
    xticklabels({'0.01','','','','','','','','','0.1','','','','','',...
        '','','','1','','','','','','','','','10','','','','','',...
        '','','','100','','','','','','','','','1000'});
    % ylim([0 300])
    legend('Non-virus-containing','Virus-containing');
    legend boxoff
    
    subplot(3,1,2)
    histogram(log10(Dp_final),binedges)
    hold on
    histogram(log10(Dp_v_final),binedges)
    hold on
    histogram(log10(Dp_v_set),binedges)
    hold off
    xlim([-8,-3])
    xlabel('{\itD}_{p,f} ({\mu}m)');
    ylabel('Counts');
    ylim([0 250]);
    yticks([0:50:250]);
    xticks(log10(tickspos));
    xticklabels({'0.01','','','','','','','','','0.1','','','','','',...
        '','','','1','','','','','','','','','10','','','','','',...
        '','','','100','','','','','','','','','1000'});
    % ylim([0 300])
    legend('Non-virus-containing','Virus-containing','Settled');
    legend boxoff
    
    subplot(3,1,3)
    tmpidxx=(z_final<1.7)&(z_final>0)&(n_virus>0)&isnan(Dp_v_set);
    z=z_final(tmpidxx);
    n_v=n_virus(tmpidxx);
    zbinedges=[0:0.1:1.7];
    histogram(z,zbinedges);
    xlim([0 1.7]);
    
    nv_bin=zeros(17,1);
    for i=1:1:length(z)
        for j=1:1:length(zbinedges)-1
            if z(i)>zbinedges(j)&&z(i)<zbinedges(j+1)
                nv_bin(j)=nv_bin(j)+n_v(i);
            end
        end
    end
    hold on
    plot([0.05:0.1:1.65],nv_bin,'-o');
    hold off
    xlabel('Vertical distance (m)')
    ylabel('Counts')
    ylim([0 100]);
    yticks([0:25:100])
    legend('Virus-containing particles','Viral copies');
    legend boxoff
    JW_figure_style(gcf,'PT_land2');
    
end

tmpidxx=n_virus>0;
[sum(tmpidxx);sum(n_virus(tmpidxx))]

tmpidxx=(z_final<1.7)&(z_final>0)&(n_virus>0)&isnan(Dp_v_set);
[sum(tmpidxx);sum(n_virus(tmpidxx))]



% 1+1
% tmpidx=(n_virus>0)&isnan(Dp_v_set);
% Dp_with_virus=Dp_final(tmpidx);
% N_aerosol=sum(Dp_with_virus<5e-6)
% N_droplet=sum(Dp_with_virus>5e-6)
% tmpidx1=(tmpidx)&(Dp_final<5e-6);
% copies_aerosol=sum(n_virus(tmpidx1))
% tmpidx2=(tmpidx)&(Dp_final>5e-6);
% copies_droplet=sum(n_virus(tmpidx2))
% 1+1;

% plot(x_final,1.7-z_final,'.');
% hold on
% % tmpidx=n_virus>0;
% % plot(x_final(tmpidx),1.7-z_final(tmpidx),'.r');
% xlabel('x (m)');
% ylabel('z (m)');
% ylim([0 2]);
% 1+1;