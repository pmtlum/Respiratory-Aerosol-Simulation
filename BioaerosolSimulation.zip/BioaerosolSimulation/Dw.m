function Diffusivity = Dw( T ) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Bennett Naden and Jake Leonardis 
% 25 April 2013 
% 
% Function defining the surface tension of water, analytical function 
Dw300 = 2.51e-5;                   % A constant [m^2/s] 

Diffusivity = Dw300*(T/300)^(3/2); 

end 
