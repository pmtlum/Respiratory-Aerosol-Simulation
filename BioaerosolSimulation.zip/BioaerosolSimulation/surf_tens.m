function sigma = surf_tens( T ) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Bennett Naden and Jake Leonardis 
% 25 April 2013 
% Aerosol Dynamics Clinic 2013 
% Combining COMSOL and Matlab to simulate droplet growth 
% 
% Function defining the surface tension of water, analytical 

sigma = -.000164*T + .12081;            % [N/m] 

end 
