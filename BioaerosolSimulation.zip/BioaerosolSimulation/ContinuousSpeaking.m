function ContinuousSpeaking
t_tot=60;
Dp_final=[];
Dp_v_final=[];
Dp_v_set=[];
n_virus=[];
z_final=[];

for i=11:1:(t_tot+10)
    i
    [Dp_ini,Dp_v_ini,Dp_final_i,Dp_v_final_i,Dp_v_set_i,n_virus_i,z_final_i]=MonteCarlo(i,50);
    Dp_final=[Dp_final,Dp_final_i];
    Dp_v_final=[Dp_v_final,Dp_v_final_i];
    Dp_v_set=[Dp_v_set,Dp_v_set_i]
    n_virus=[n_virus,n_virus_i];
    z_final=[z_final,z_final_i];
end
1+1
tickspos=[[1:1:9]*10^-8,[1:1:9]*10^-7,[1:1:9]*10^-6,[1:1:9]*10^-5,[1:1:10]*10^-4];
binedges=[-8:0.1:3];

subplot(3,1,1)
% histogram(log10(Dp_ini),binedges)
% hold on
% histogram(log10(Dp_v_ini),binedges)
% xlim([-8,-3])
% xlabel('{\itD}_{p,i} ({\mu}m)');
% ylabel('Counts');
%     ylim([0 10]);
%     yticks([0:2:10]);
% xticks(log10(tickspos));
% xticklabels({'0.01','','','','','','','','','0.1','','','','','',...
%     '','','','1','','','','','','','','','10','','','','','',...
%     '','','','100','','','','','','','','','1000'});
% % ylim([0 300])
% legend('Non-virus-containing','Virus-containing');
% legend boxoff

FE_grpChen=[
1.62357E-07	0.54501953
2.08696E-07	0.52413308
2.6421E-07	0.47433466
3.12478E-07	0.470051871
3.74708E-07	0.461624446
5.10008E-07	0.469612288
6.5648E-07	0.481782444
7.7803E-07	0.527084563
8.96318E-07	0.564147649
1.03313E-06	0.613606963
1.14166E-06	0.658971879
1.28003E-06	0.716720463
1.39507E-06	0.766230015
1.58566E-06	0.815701888
1.77693E-06	0.861054244
2.01828E-06	0.893997815
2.32554E-06	0.935192977
2.91382E-06	0.972180706
3.64838E-06	0.992640133
4.8295E-06	1
6.38967E-06	1
];
FE_grpHao=[3.35204E-08	0.7977147
3.87352E-08	0.793095785
4.4403E-08	0.786119097
5.21417E-08	0.774451021
5.9293E-08	0.750998913
6.85171E-08	0.741674115
7.98148E-08	0.71353062
9.07615E-08	0.690078512
1.04881E-07	0.659577244
1.21197E-07	0.631428917
1.41181E-07	0.591520715
1.61839E-07	0.577485204
1.88525E-07	0.549341708
2.17853E-07	0.530605146
2.53775E-07	0.514226356
2.93254E-07	0.502548617
3.41608E-07	0.507346298
4.01145E-07	0.507442928
4.56162E-07	0.509873173
5.14575E-07	0.528769175
5.80469E-07	0.535900471
6.70771E-07	0.615987438
7.94028E-07	0.686677135
9.55157E-07	0.776200024
1.11265E-06	0.818644764
1.30657E-06	0.868153159
1.53428E-06	0.945896847
1.81621E-06	0.941292427
];

plot(FE_grpChen(:,1)*1e6,FE_grpChen(:,2)*100,'o-',FE_grpHao(:,1)*1e6,FE_grpHao(:,2)*100,'+-');
xlim([0.01 1000])
ylim([0 100]);
set(gca,'xscale','log');
xticks([0.01 0.1 1 10 100 1000]);
xticklabels({'0.01', '0.1', '1', '10', '100', '1000'});
xlabel('{\itD}_{p,i} ({\mu}m)');
ylabel('Filtration efficiency (%)');
legend('Chen et al., 1992','Hao et al., 2020');
legend boxoff

subplot(3,1,2)
histogram(log10(Dp_final),binedges)
hold on
histogram(log10(Dp_v_final),binedges)
hold on
histogram(log10(Dp_v_set),binedges)
hold off
xlim([-8,-3])
xlabel('{\itD}_{p,f} ({\mu}m)');
ylabel('Counts');
%     ylim([0 300]);
%     yticks([0:50:300]);
xticks(log10(tickspos));
xticklabels({'0.01','','','','','','','','','0.1','','','','','',...
    '','','','1','','','','','','','','','10','','','','','',...
    '','','','100','','','','','','','','','1000'});
% ylim([0 300])
legend('Non-virus-containing','Virus-containing','Settled');
legend boxoff

subplot(3,1,3)
tmpidxx=(z_final<1.7)&(z_final>0)&(n_virus>0)&isnan(Dp_v_set);
z=z_final(tmpidxx);
n_v=n_virus(tmpidxx);
zbinedges=[0:0.1:1.7];
histogram(z,zbinedges);
xlim([0 1.7]);

nv_bin=zeros(17,1);
for i=1:1:length(z)
    for j=1:1:length(zbinedges)-1
        if z(i)>zbinedges(j)&&z(i)<zbinedges(j+1)
            nv_bin(j)=nv_bin(j)+n_v(i);
        end
    end
end
hold on
plot([0.05:0.1:1.65],nv_bin*0.1,'-o');
hold off
xlabel('Vertical distance (m)')
ylabel('Counts')
% ylim([0 80])
%     ylim([0 3000]);
%     yticks([0:1000:3000]);
legend('Virus-containing particles','Viral copies * 0.1');
legend boxoff
JW_figure_style(gcf,'PT_land2');
set(gcf,'Position',[90 20 600 800])